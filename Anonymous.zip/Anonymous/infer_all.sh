#!/bin/bash

template_dict=./template/dict.pkl
config=./configs/test/codesign_multiple_100.yml

# 获取测试集大小
test_size=$(python -c "
from CCFlow.datasets import get_dataset
from CCFlow.utils.config import load_config
config, _ = load_config('$config')
dataset = get_dataset(config.dataset.test)
print(len(dataset))")

echo "测试集大小: $test_size"

# 对每个测试集样本进行推理采样
for i in $(seq 0 $((test_size-1)))
do
   echo "正在处理测试样本 $i"
   python design_testset.py --template_dict $template_dict -c $config -b 32 $i
done
