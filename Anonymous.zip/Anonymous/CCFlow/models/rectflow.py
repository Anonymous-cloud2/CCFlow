import torch
import torch.nn as nn

from CCFlow.modules.common.geometry import construct_3d_basis
from CCFlow.modules.common.so3 import rotation_to_so3vec, so3vec_to_rotation, random_uniform_so3
from CCFlow.modules.encoders.residue import ResidueEmbedding
from CCFlow.modules.encoders.pair import PairEmbedding
from CCFlow.modules.rectified_flow.rectflow import RectFlowGenerator
from CCFlow.utils.protein.constants import max_num_heavyatoms, BBHeavyAtom
from ._base import register_model

import pickle

resolution_to_num_atoms = {
    'backbone+CB': 5,
    'full': max_num_heavyatoms
}

@register_model('rectflow')
class RectFlowAntibodyDesign(nn.Module):

    def __init__(self, cfg):
        super().__init__()
        self.cfg = cfg

        num_atoms = resolution_to_num_atoms[cfg.get('resolution', 'full')]
        self.residue_embed = ResidueEmbedding(cfg.res_feat_dim, num_atoms)
        self.pair_embed = PairEmbedding(cfg.pair_feat_dim, num_atoms)

        # 从train配置中获取增强损失配置（注意：这个配置是在train.enhanced_loss中）
        # 这里我们假设cfg包含了完整的train配置，或者在train.py中会将train配置传递给model
        enhanced_loss_config = cfg.get('enhanced_loss_config', {})
        
        # 始终统一初始化：建议在 Config 中控制是否启用 enhanced_loss，而不是依赖 self.training
        self.rectflow_seq_only = RectFlowGenerator(
            cfg.res_feat_dim,
            cfg.pair_feat_dim,
            enhanced_loss_config=enhanced_loss_config,  # 始终传入配置
            **cfg.diffusion,
        )

    def encode(self, batch, remove_structure, remove_sequence):
        """
        Returns:
            res_feat:   (N, L, res_feat_dim)
            pair_feat:  (N, L, L, pair_feat_dim)
        """
        # This is used throughout embedding and encoding layers
        #   to avoid data leakage.
        context_mask = torch.logical_and(
            batch['mask_heavyatom'][:, :, BBHeavyAtom.CA], 
            ~batch['generate_flag']     # Context means ``not generated''
        )

        structure_mask = context_mask if remove_structure else None
        sequence_mask = context_mask if remove_sequence else None

        res_feat = self.residue_embed(
            aa = batch['aa'],
            res_nb = batch['res_nb'],
            chain_nb = batch['chain_nb'],
            pos_atoms = batch['pos_heavyatom'],
            mask_atoms = batch['mask_heavyatom'],
            fragment_type = batch['fragment_type'],
            structure_mask = structure_mask,
            sequence_mask = sequence_mask,
        )

        pair_feat = self.pair_embed(
            aa = batch['aa'],
            res_nb = batch['res_nb'],
            chain_nb = batch['chain_nb'],
            pos_atoms = batch['pos_heavyatom'],
            mask_atoms = batch['mask_heavyatom'],
            structure_mask = structure_mask,
            sequence_mask = sequence_mask,
        )

        R = construct_3d_basis(
            batch['pos_heavyatom'][:, :, BBHeavyAtom.CA],
            batch['pos_heavyatom'][:, :, BBHeavyAtom.C],
            batch['pos_heavyatom'][:, :, BBHeavyAtom.N],
        )

        p = batch['pos_heavyatom'][:, :, BBHeavyAtom.CA] ### CA only

        # Check if template exists in batch
        if 'template' in batch and batch['template'] is not None:
            template = batch['template']
            templateR = construct_3d_basis(
                template['pos_heavyatom'][:, :, BBHeavyAtom.CA],
                template['pos_heavyatom'][:, :, BBHeavyAtom.C],
                template['pos_heavyatom'][:, :, BBHeavyAtom.N],
            )
            templatep = template['pos_heavyatom'][:, :, BBHeavyAtom.CA]
        else:
            # Create empty templateR and templatep with same shape as R and p when no template
            templateR = torch.zeros_like(R)
            templatep = torch.zeros_like(p)

        return res_feat, pair_feat, R, p, templateR, templatep
    
    def forward(self, batch, epoch_ratio=None):
        mask_generate = batch['generate_flag']
        mask_res = batch['mask']
        mask_anchor = batch['anchor_flag']
        
        # 识别H_CDR3区域
        mask_hcdr3 = torch.zeros_like(mask_generate)
        if 'cdr_type' in batch:
            # 假设cdr_type是一个整数张量，其中3代表H_CDR3
            mask_hcdr3 = batch['cdr_type'] == 3
        
        res_feat, pair_feat, R_0, p_0, R_template, p_template = self.encode(
            batch,
            remove_structure = self.cfg.get('train_structure', True),
            remove_sequence = self.cfg.get('train_sequence', True)
        )

        s_0 = batch['aa']
        
        # Check if template exists in batch
        if 'template' in batch and batch['template'] is not None:
            template = batch['template']
            s_template = template['aa']
            mask_template_generate = template['generate_flag']
            template_enable = batch['template_enable']
            template_mask = torch.rand(template_enable.shape, device=template_enable.device) < 0.3
            template_enable = template_enable & template_mask
        else:
            # Create dummy template values when template is not available
            s_template = s_0.clone()
            mask_template_generate = torch.zeros_like(batch['generate_flag'])
            # Create template_enable as zeros when no template exists
            template_enable = torch.zeros(mask_generate.shape, device=mask_generate.device, dtype=torch.bool)

        pdbid = batch['id']
        
        loss_dict = self.rectflow_seq_only(
            R_0, p_0, s_0, res_feat, pair_feat, mask_generate, mask_res,
            mask_anchor, R_template, p_template, s_template, 
            mask_template_generate,
            denoise_structure = self.cfg.get('train_structure', True),
            denoise_sequence  = self.cfg.get('train_sequence', True),
            template_enable = template_enable, 
            pdbid=pdbid,
            epoch_ratio=epoch_ratio,
            chain_nb = batch['chain_nb'],
            res_nb = batch['res_nb'],
            mask_hcdr3 = mask_hcdr3
        )
        return loss_dict

    @torch.no_grad()
    def sample(
        self, 
        batch, 
        sample_opt={
            'sample_structure': True,
            'sample_sequence': True,
        }
    ):
        mask_generate = batch['generate_flag']
        mask_res = batch['mask']
        mask_anchor = batch['anchor_flag']
        
        # 识别 H_CDR3 区域
        mask_hcdr3 = torch.zeros_like(mask_generate)
        if 'cdr_type' in batch:
            mask_hcdr3 = batch['cdr_type'] == 3
        
        # 编码
        res_feat, pair_feat, R_0, p_0, R_template, p_template = self.encode(
            batch,
            remove_structure = sample_opt.get('sample_structure', True),
            remove_sequence = sample_opt.get('sample_sequence', True)
        )
        s_0 = batch['aa']
        
        # === [修复点] 显式获取 s_template ===
        s_template = None
        if R_template is not None:
            # 如果存在结构模板，通常 batch['template'] 里也会有序列模板 'aa'
            if 'template' in batch and batch['template'] is not None:
                s_template = batch['template']['aa']
        # ===================================
        
        template_enable = False
        mask_template_generate = None
        if R_template is not None:
            template_enable = True
            mask_template_generate = batch['generate_flag']

        # 调用底层 sample
        traj = self.rectflow_seq_only.sample(
            R_0, p_0, s_0, res_feat, pair_feat, 
            mask_generate, mask_res, mask_anchor,
            template_enable=template_enable,
            R_template=R_template,
            p_template=p_template,
            s_template=s_template,  # 现在 s_template 已经被定义了
            mask_template_generate=mask_template_generate,
            mask_hcdr3=mask_hcdr3,
            **sample_opt  # 传入 temperature 和 num_steps
        )
        return traj