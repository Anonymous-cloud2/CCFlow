import pickle
import random
with open ('./rectflow_seq_sabdab/template/dict.pkl', 'rb') as f:
    a = pickle.load(f)

print(a)