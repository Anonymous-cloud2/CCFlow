import torch
import torch.nn as nn
import torch.nn.functional as F

class EnhancedFlowDesignConsistencyLoss(nn.Module):
    def __init__(self, config):
        super().__init__()
        self.config = config
        self.seq_dim = config.get('seq_feature_dim')
        self.res_dim = config.get('residue_feature_dim')
        self.pair_dim = config.get('pair_feature_dim')
        self.num_aa = config.get('num_aa', 20)  # num_aa 可以保留默认值20
        

        assert self.seq_dim is not None, "Config must include 'seq_feature_dim'"
        assert self.res_dim is not None, "Config must include 'residue_feature_dim'"
        assert self.pair_dim is not None, "Config must include 'pair_feature_dim'"
        self.use_feature_alignment = config.get('use_feature_alignment', True)
        self.use_residual_consistency = config.get('use_residual_consistency', True)
        self.use_contact_alignment = config.get('use_contact_alignment', True)
        
        self.feat_weight = config.get('feat_weight', 0.1)
        self.residual_weight = config.get('residual_weight', 0.05)
        self.contact_weight = config.get('contact_weight', 0.02)
        self.temperature = config.get('temperature', 2.0)
-

        if self.seq_dim != self.res_dim:
            self.feat_projection = nn.Linear(self.seq_dim, self.res_dim)
        else:
            self.feat_projection = nn.Identity()

        self.local_conv = nn.Conv1d(self.res_dim, self.res_dim, kernel_size=3, padding=1, bias=False)

        self.geometric_feature_dim = 4  # 1(dist) + 1(angle) + 2(torsion sin/cos)
        self.geo_context_conv = nn.Conv1d(self.num_aa, 64, kernel_size=3, padding=1)
        self.aa_to_geo_predictor = nn.Sequential(
            nn.Linear(64, 128),
            nn.ReLU(),
            nn.Linear(128, self.geometric_feature_dim)
        )

        self.contact_predictor = nn.Sequential(
            nn.Linear(self.pair_dim, 64),
            nn.ReLU(),
            nn.Linear(64, 1)
        )

        self.feature_loss_clip = config.get('feature_loss_clip', 5.0)
        self.contact_loss_clip = config.get('contact_loss_clip', 2.0)
        self.max_sequence_length = config.get('max_sequence_length', 50)

    def forward(self, batch, model_outputs, t=None, epoch=None):
        losses = {}
        total_consistency_loss = torch.tensor(0.0, device=batch['mask'].device)
        
        # 计算课程因子 - 移除内存检查逻辑，防止 DDP 死锁和训练不稳定
        # curriculum_factor = self._get_curriculum_factor(t, epoch)
        general_curriculum_factor = self._get_curriculum_factor(t, epoch)

        if epoch is not None:
            # 线性衰减：开始是 1.0，结束是 0.0
            # 逻辑：前期靠它引导 Encoder，后期关掉防止干扰流轨迹
            feat_align_factor = max(0.0, 1.0 - epoch) 
        else:
            feat_align_factor = 1.0

        if self.use_feature_alignment:
            seq_feat = model_outputs.get('sequence_features')
            res_feat = model_outputs.get('residue_features')
            
            if seq_feat is not None and res_feat is not None:
     
                seq_feat = self.feat_projection(seq_feat)
                

                feat_alignment = self._compute_feature_alignment(
                    seq_feat, res_feat, batch
                )
                losses['feat_alignment'] = feat_alignment

                total_consistency_loss += self.feat_weight * feat_alignment * feat_align_factor
        

        if self.use_residual_consistency:
            ca_coords = model_outputs.get('ca_coords')
            seq_logits = model_outputs.get('sequence_logits')
            
            if ca_coords is not None and seq_logits is not None:
                residual_loss = self._compute_residual_consistency(
                    seq_logits, ca_coords, batch
                )
                losses['residual'] = residual_loss
   
                total_consistency_loss += self.residual_weight * residual_loss * general_curriculum_factor
        

        if self.use_contact_alignment:
            if self._should_compute_contact_loss(batch):
                contact_loss = self._compute_lightweight_contact_alignment(
                    model_outputs, batch
                )
                if contact_loss > 0:
                    losses['contact'] = contact_loss
                    total_consistency_loss += self.contact_weight * contact_loss * curriculum_factor
        
        return total_consistency_loss, losses
    
    def _compute_feature_alignment(self, seq_feat, res_feat, batch):


        mask = batch['mask'] 
        B, L, seq_dim = seq_feat.shape    
        _, _, res_dim = res_feat.shape

        if seq_dim != res_dim:

            create_new_projection = False
            
            if not hasattr(self, 'feat_projection'):
                create_new_projection = True
            elif isinstance(self.feat_projection, nn.Identity):
                create_new_projection = True
            else:
                try:
                    if self.feat_projection.in_features != seq_dim or self.feat_projection.out_features != res_dim:
                        create_new_projection = True
                except AttributeError:
                    create_new_projection = True
            
            if create_new_projection:
                device = seq_feat.device
                self.feat_projection = nn.Linear(seq_dim, res_dim, device=device)
            seq_feat_projected = self.feat_projection(seq_feat)
        else:
            seq_feat_projected = seq_feat
        seq_feat_norm = F.normalize(seq_feat_projected, dim=-1, eps=1e-8)
        res_feat_norm = F.normalize(res_feat, dim=-1, eps=1e-8)
        cosine_sim = torch.sum(seq_feat_norm * res_feat_norm, dim=-1)  # [B, L]
        cosine_sim = torch.clamp(cosine_sim, -1.0, 1.0)
        alignment_loss_per_token = (1.0 - cosine_sim) * mask
        weights = torch.ones_like(alignment_loss_per_token)

        if 'mask_hcdr3' in batch and batch['mask_hcdr3'] is not None:
            hcdr3_mask = batch['mask_hcdr3']
            if hcdr3_mask.shape == weights.shape:
                weights = weights + 4.0 * hcdr3_mask
        loss = (alignment_loss_per_token * weights).sum() / ( (mask * weights).sum() + 1e-5 )
        
        loss = torch.clamp(loss, 0, self.feature_loss_clip)
        if L > 3:
            seq_local = self._get_local_context(seq_feat_projected)
            res_local = self._get_local_context(res_feat)
            
            seq_local_norm = F.normalize(seq_local, dim=-1, eps=1e-8)
            res_local_norm = F.normalize(res_local, dim=-1, eps=1e-8)

            local_cosine_sim = torch.sum(seq_local_norm * res_local_norm, dim=-1)
            local_cosine_sim = torch.clamp(local_cosine_sim, -1.0, 1.0)
            local_alignment_loss = (1.0 - local_cosine_sim) * mask
            local_loss = (local_alignment_loss * weights).sum() / ( (mask * weights).sum() + 1e-5 )
            local_loss = torch.clamp(local_loss, 0, self.feature_loss_clip)
            loss = 0.7 * loss + 0.3 * local_loss

        loss = torch.clamp(loss, max=10.0)
        return loss
    def _compute_residual_consistency(self, seq_logits, ca_coords, batch):
        mask = batch['mask']
        B, L, num_aa = seq_logits.shape
        
        with torch.no_grad():
            # geo_targets: [B, L, D_geo], geo_mask: [B, L, 1]
            geo_targets, geo_mask = self._extract_geometric_features(ca_coords, mask)
            
        aa_probs = F.softmax(seq_logits / self.temperature, dim=-1)  # [B, L, 20]
        aa_context = self.geo_context_conv(aa_probs.transpose(1, 2)).transpose(1, 2)
        
        predicted_geo = self.aa_to_geo_predictor(aa_context)  # [B, L, D_geo]
        
        # -------------------------------------------------------------------------
        # [修改] 使用 Huber Loss 替换 MSE Loss
        # delta=1.0 是默认值，意味着误差大于1时使用L1，小于1时使用L2
        # 这对几何预测（距离、角度）的鲁棒性更好
        # -------------------------------------------------------------------------
        loss_per_token = F.huber_loss(predicted_geo, geo_targets, reduction='none', delta=1.0) # [B, L, D_geo]
        
        loss_per_token = loss_per_token.mean(dim=-1) # [B, L]

        final_mask = mask * geo_mask.squeeze(-1) # [B, L]
        
        weights = torch.ones_like(loss_per_token)
        if 'mask_hcdr3' in batch and batch['mask_hcdr3'] is not None:
            hcdr3_mask = batch['mask_hcdr3']
            if hcdr3_mask.shape == weights.shape:
                weights = weights + 4.0 * hcdr3_mask
        
        loss = (loss_per_token * weights * final_mask).sum() / ( (weights * final_mask).sum() + 1e-5 )
        loss = torch.clamp(loss, max=10.0)
        return loss
    
    def _compute_lightweight_contact_alignment(self, model_outputs, batch):
        pair_feat = model_outputs.get('pair_features')  # [B, L, L, D_pair]
        
        if pair_feat is None:
            return 0.0
        
        B, L, _, D_pair = pair_feat.shape

        mask = batch['mask']
        max_length = mask.sum(dim=1).max().item()
        if max_length > self.max_sequence_length:
            return 0.0
        if L < 8:
            return 0.0

        contact_logits = self.contact_predictor(pair_feat).squeeze(-1)  # [B, L, L]
        ca_coords = model_outputs.get('ca_coords')
        if ca_coords is not None:

            diff = ca_coords.unsqueeze(2) - ca_coords.unsqueeze(1)  # [B, L, L, 3]
            distances = torch.norm(diff, dim=-1)  # [B, L, L]
            distances = torch.clamp(distances, 0, 20.0)
            
            pos_mask = mask.unsqueeze(1) * mask.unsqueeze(2)
            diag_mask = 1 - torch.eye(L, device=ca_coords.device).unsqueeze(0)
            full_mask = pos_mask * diag_mask

            true_contacts = (distances < 8.0).float() * full_mask
            contact_loss = F.binary_cross_entropy_with_logits(
                contact_logits,
                true_contacts,
                weight=full_mask,
                reduction='sum'
            ) / (full_mask.sum() + 1e-8)
            
            contact_loss = torch.clamp(contact_loss, 0, self.contact_loss_clip)
            
            return contact_loss
        
        return 0.0
    
    def _get_curriculum_factor(self, t, epoch):
        if t is None:
            return 1.0
        t_val = t.mean().item() if torch.is_tensor(t) else t
        time_factor = t_val 
        
        if epoch is not None:
            if epoch <= 1.0:
                epoch_factor = max(0.0, min(1.0, epoch))
            else:
                epoch_factor = min(1.0, epoch / 50.0)
        else:
            epoch_factor = 1.0
        curriculum_factor = time_factor * epoch_factor
        curriculum_factor = min(0.8, curriculum_factor)
        
        return curriculum_factor
    
    def _get_local_context(self, feat):
        B, L, D = feat.shape
        
        if L < 3:  
            return feat
        feat_conv = feat.permute(0, 2, 1)
        local_feat = self.local_conv(feat_conv)
        local_feat = local_feat.permute(0, 2, 1)
        
        return local_feat
    
    def _extract_geometric_features(self, ca_coords, mask):
        B, L, _ = ca_coords.shape
        device = ca_coords.device
        
        geometric_features = torch.zeros(B, L, self.geometric_feature_dim, device=device)
        geo_mask = torch.zeros(B, L, 1, device=device)
        if L > 1:
            dist = torch.norm(ca_coords[:, 1:] - ca_coords[:, :-1], dim=-1, keepdim=True)  # [B, L-1, 1]
            dist = F.pad(dist, (0, 0, 0, 1), value=0)  # [B, L, 1]
            dist_mask = torch.ones(B, L, 1, device=device)
            dist_mask[:, -1, :] = 0 
        else:
            dist = torch.zeros(B, L, 1, device=device)
            dist_mask = torch.zeros(B, L, 1, device=device)
        if L > 2:
            v1 = ca_coords[:, 1:-1] - ca_coords[:, :-2]
            v2 = ca_coords[:, 2:] - ca_coords[:, 1:-1]
            
            v1 = F.normalize(v1, dim=-1, eps=1e-6)
            v2 = F.normalize(v2, dim=-1, eps=1e-6)
            
            cos_angle = torch.sum(v1 * v2, dim=-1, keepdim=True)
            cos_angle = torch.clamp(cos_angle, -1.0 + 1e-6, 1.0 - 1e-6)

            angle = torch.acos(cos_angle)  # [B, L-2, 1]

            angle = F.pad(angle, (0, 0, 1, 1), value=0)  # [B, L, 1]

            angle_mask = torch.zeros(B, L, 1, device=device)
            angle_mask[:, 1:-1, :] = 1  
        else:
            angle = torch.zeros(B, L, 1, device=device)
            angle_mask = torch.zeros(B, L, 1, device=device)
        if L > 3:
            # 计算扭角
            b1 = ca_coords[:, :-3] - ca_coords[:, 1:-2]
            b2 = ca_coords[:, 1:-2] - ca_coords[:, 2:-1]
            b3 = ca_coords[:, 2:-1] - ca_coords[:, 3:]
            
            n1 = torch.cross(b1, b2, dim=-1)
            n2 = torch.cross(b2, b3, dim=-1)
            
            # 归一化
            n1 = F.normalize(n1, dim=-1)
            n2 = F.normalize(n2, dim=-1)
            b2_norm = F.normalize(b2, dim=-1)
            
            # 计算 cos 和 sin
            cos_torsion = torch.sum(n1 * n2, dim=-1).unsqueeze(-1)
            sin_torsion = torch.sum(torch.cross(n1, n2, dim=-1) * b2_norm, dim=-1).unsqueeze(-1)
            
            # 拼接 sin 和 cos [B, L-3, 2]
            torsion_feat = torch.cat([sin_torsion, cos_torsion], dim=-1)
            
            # 初始化扭角特征张量
            full_torsion = torch.zeros(B, L, 2, device=device)
            # 将计算的扭角特征填充到有效位置
            full_torsion[:, 2:-1, :] = torsion_feat

            torsion_mask = torch.zeros(B, L, 1, device=device)
            torsion_mask[:, 2:-1, :] = 1  # 中间位置有效
        else:
            full_torsion = torch.zeros(B, L, 2, device=device)
            torsion_mask = torch.zeros(B, L, 1, device=device)
        
        # 拼接所有几何特征: [dist(1), angle(1), torsion_sin(1), torsion_cos(1)]
        geometric_features = torch.cat([dist, angle, full_torsion], dim=-1)
        
        # 计算总掩码：所有特征都有效的位置才有效
        geo_mask = dist_mask * angle_mask * torsion_mask
        
        return geometric_features, geo_mask
    
    def _should_compute_contact_loss(self, batch):
        mask = batch['mask']
        max_length = mask.sum(dim=1).max().item()
        return max_length > 10  # 只对长度大于10的序列计算
