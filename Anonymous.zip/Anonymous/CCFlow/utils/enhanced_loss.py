import torch
import torch.nn as nn
import torch.nn.functional as F

class EnhancedFlowDesignConsistencyLoss(nn.Module):
    def __init__(self, config):
        super().__init__()
        self.config = config
        
        # 1. 维度获取
        self.seq_dim = config.get('seq_feature_dim')
        self.res_dim = config.get('residue_feature_dim')
        self.pair_dim = config.get('pair_feature_dim')
        self.num_aa = config.get('num_aa', 20)
        
        assert self.seq_dim is not None and self.res_dim is not None, "Missing feature dimensions in config"

        loss_weights = config.get('weights', {})
        self.feat_weight = loss_weights.get('feat_alignment', 0.1)
        self.residual_weight = loss_weights.get('residual', 0.05)
        self.contact_weight = loss_weights.get('contact', 0.02)
        
        self.temperature = config.get('temperature', 2.0)
        self.feature_loss_clip = config.get('feature_loss_clip', 5.0)
        self.contact_loss_clip = config.get('contact_loss_clip', 2.0)

        # 3. 网络层定义
        self.feat_projection = nn.Linear(self.seq_dim, self.res_dim) if self.seq_dim != self.res_dim else nn.Identity()
        self.local_conv = nn.Conv1d(self.res_dim, self.res_dim, kernel_size=3, padding=1, bias=False)

        # 几何预测器 (1 dist + 1 angle + 2 torsion sin/cos = 4 dims)
        self.geometric_feature_dim = 4
        self.geo_context_conv = nn.Conv1d(self.num_aa, 64, kernel_size=3, padding=1)
        self.aa_to_geo_predictor = nn.Sequential(
            nn.Linear(64, 128), nn.ReLU(), nn.Linear(128, self.geometric_feature_dim)
        )
        self.contact_predictor = nn.Sequential(
            nn.Linear(self.pair_dim, 64), nn.ReLU(), nn.Linear(64, 1)
        )

    def _get_curriculum_factor(self, t, epoch):
        if t is None: return 1.0
        t_val = t.mean().item() if torch.is_tensor(t) else t
        epoch_factor = min(1.0, (epoch + 1) / 50.0) if epoch is not None else 1.0
        return t_val * epoch_factor

    def forward(self, batch, model_outputs, t=None, epoch=None):
        losses = {}
        mask = batch['mask']
        alpha = self._get_curriculum_factor(t, epoch)
        
        weights = torch.ones_like(mask).float() 
        if 'mask_all_cdr' in batch:
            weights += 4.0 * batch['mask_all_cdr'].float()
        if 'mask_hcdr3' in batch:
            weights += 4.0 * batch['mask_hcdr3'].float()  
            
        total_loss = torch.tensor(0.0, device=mask.device)

        if self.config.get('use_feature_alignment', True):
            seq_feat = self.feat_projection(model_outputs['sequence_features'])
            res_feat = model_outputs['residue_features']
            feat_loss = self._compute_feature_alignment(seq_feat, res_feat, mask, weights)
            losses['feat_alignment'] = feat_loss
            total_loss += self.feat_weight * feat_loss * alpha

        if self.config.get('use_residual_consistency', True):
            ca_coords = model_outputs['ca_coords']
            seq_logits = model_outputs['sequence_logits']
            res_loss = self._compute_residual_consistency(seq_logits, ca_coords, mask, weights)
            losses['residual'] = res_loss
            total_loss += self.residual_weight * res_loss * alpha

        if self.config.get('use_contact_alignment', True) and self._should_compute_contact_loss(batch):
            contact_loss = self._compute_lightweight_contact_alignment(model_outputs, batch)
            if contact_loss > 0:
                losses['contact'] = contact_loss
                total_loss += self.contact_weight * contact_loss * alpha
        
        return total_loss, losses

    def _compute_feature_alignment(self, seq_feat, res_feat, mask, weights):
        # 归一化余弦相似度
        cos_sim = torch.sum(F.normalize(seq_feat, dim=-1) * F.normalize(res_feat, dim=-1), dim=-1)
        cos_sim = torch.clamp(cos_sim, -1.0, 1.0)
        global_loss = ((1.0 - cos_sim) * mask * weights).sum() / ((mask * weights).sum() + 1e-6)
        
        # 局部拓扑一致性 (Conv1d)
        seq_local = self.local_conv(seq_feat.permute(0, 2, 1)).permute(0, 2, 1)
        res_local = self.local_conv(res_feat.permute(0, 2, 1)).permute(0, 2, 1)
        local_sim = torch.sum(F.normalize(seq_local, dim=-1) * F.normalize(res_local, dim=-1), dim=-1)
        local_loss = ((1.0 - torch.clamp(local_sim, -1.0, 1.0)) * mask * weights).sum() / ((mask * weights).sum() + 1e-6)
        
        loss = 0.7 * global_loss + 0.3 * local_loss
        return torch.clamp(loss, 0, self.feature_loss_clip)

    def _compute_residual_consistency(self, seq_logits, ca_coords, mask, weights):
        with torch.no_grad():
            geo_targets, geo_mask = self._extract_geometric_features(ca_coords, mask)
            
        aa_probs = F.softmax(seq_logits / self.temperature, dim=-1)
        aa_context = self.geo_context_conv(aa_probs.transpose(1, 2)).transpose(1, 2)
        predicted_geo = self.aa_to_geo_predictor(aa_context)
        loss_per_token = F.huber_loss(predicted_geo, geo_targets, reduction='none', delta=1.0).mean(dim=-1)
        final_mask = mask * geo_mask.squeeze(-1)
        loss = (loss_per_token * weights * final_mask).sum() / ((weights * final_mask).sum() + 1e-6)
        return torch.clamp(loss, max=10.0)

    def _extract_geometric_features(self, ca_coords, mask):
        B, L, _ = ca_coords.shape
        device = ca_coords.device
        geo_feat = torch.zeros(B, L, 4, device=device)
        geo_mask = torch.zeros(B, L, 1, device=device)
        
        if L > 1:
            dist = F.pad(torch.norm(ca_coords[:, 1:] - ca_coords[:, :-1], dim=-1, keepdim=True), (0,0,0,1))
            geo_feat[:, :, 0:1] = dist
        if L > 2:
            v1, v2 = F.normalize(ca_coords[:, 1:-1] - ca_coords[:, :-2], dim=-1), F.normalize(ca_coords[:, 2:] - ca_coords[:, 1:-1])
            angle = F.pad(torch.acos(torch.clamp(torch.sum(v1 * v2, dim=-1, keepdim=True), -1+1e-6, 1-1e-6)), (0,0,1,1))
            geo_feat[:, :, 1:2] = angle
        if L > 3:
            b1, b2, b3 = ca_coords[:, :-3]-ca_coords[:, 1:-2], ca_coords[:, 1:-2]-ca_coords[:, 2:-1], ca_coords[:, 2:-1]-ca_coords[:, 3:]
            n1, n2 = F.normalize(torch.cross(b1, b2, dim=-1), dim=-1), F.normalize(torch.cross(b2, b3, dim=-1), dim=-1)
            cos_t = torch.sum(n1 * n2, dim=-1, keepdim=True)
            sin_t = torch.sum(torch.cross(n1, n2, dim=-1) * F.normalize(b2, dim=-1), dim=-1, keepdim=True)
            geo_feat[:, 2:-1, 2:4] = torch.cat([sin_t, cos_t], dim=-1)
            geo_mask[:, 2:-1, :] = 1.0
        return geo_feat, geo_mask

    def _compute_lightweight_contact_alignment(self, model_outputs, batch):
        pair_feat = model_outputs.get('pair_features')  # [B, L, L, D_pair]
        ca_coords = model_outputs.get('ca_coords')      # [B, L, 3]
        mask = batch['mask']

        cdr_mask = batch.get('mask_all_cdr', batch.get('mask_hcdr3', batch.get('mask_generate')))
        
        if pair_feat is None or ca_coords is None or cdr_mask is None or cdr_mask.sum() == 0:
            return torch.tensor(0.0, device=mask.device)

        B, L, _, _ = pair_feat.shape
        cdr_mask = cdr_mask.bool()
        total_contact_loss = torch.tensor(0.0, device=mask.device)
        valid_samples = 0

        for i in range(B):
            indices = torch.where(cdr_mask[i])[0]
            L_cdr = len(indices)
            if L_cdr < 4 or L_cdr > 160: 
                continue
            sub_pair_feat = pair_feat[i, indices, :][:, indices]
            sub_ca_coords = ca_coords[i, indices]

            logits = self.contact_predictor(sub_pair_feat).squeeze(-1) # [L_cdr, L_cdr]

            dist = torch.cdist(sub_ca_coords.unsqueeze(0), sub_ca_coords.unsqueeze(0), p=2).squeeze(0)

            diag_mask = 1.0 - torch.eye(L_cdr, device=mask.device)
            target = (dist < 8.0).float() * diag_mask

            total_contact_loss += F.binary_cross_entropy_with_logits(logits, target, reduction='mean')
            valid_samples += 1

        if valid_samples > 0:
            avg_loss = total_contact_loss / valid_samples
            return torch.clamp(avg_loss, 0, self.contact_loss_clip)
        
        return torch.tensor(0.0, device=mask.device)

    def _should_compute_contact_loss(self, batch):
        return any(k in batch for k in ['mask_all_cdr', 'mask_hcdr3', 'mask_generate'])