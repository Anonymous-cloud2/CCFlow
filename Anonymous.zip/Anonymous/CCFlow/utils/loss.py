import torch
from typing import Optional, Tuple


def compute_fape(
    pred_frames: Tuple[torch.Tensor, torch.Tensor],
    target_frames: Tuple[torch.Tensor, torch.Tensor],
    frames_mask: torch.Tensor,
    pred_positions: Optional[torch.Tensor] = None,
    target_positions: Optional[torch.Tensor] = None,
    positions_mask: Optional[torch.Tensor] = None,
    length_scale: float = 10.0,
    pair_mask: Optional[torch.Tensor] = None,
    l1_clamp_distance: Optional[float] = None,
    eps: float = 1e-8,
) -> torch.Tensor:
    """
    Computes FAPE loss.
    
    Args:
        pred_frames: Tuple of (R, t) where:
            R: [*, N_frames, 3, 3] predicted rotation matrices
            t: [*, N_frames, 3] predicted translation vectors
        target_frames: Tuple of (R, t) where:
            R: [*, N_frames, 3, 3] ground truth rotation matrices
            t: [*, N_frames, 3] ground truth translation vectors
        frames_mask: [*, N_frames] binary mask for the frames
        pred_positions: [*, N_pts, 3] predicted atom positions. If None, uses t from pred_frames
        target_positions: [*, N_pts, 3] ground truth positions. If None, uses t from target_frames
        positions_mask: [*, N_pts] positions mask. If None, uses frames_mask
        length_scale: Length scale by which the loss is divided
        pair_mask: [*, N_frames, N_pts] mask to use for separating intra- from inter-chain losses.
        l1_clamp_distance: Cutoff above which distance errors are disregarded
        eps: Small value used to regularize denominators
    
    Returns:
        [*] loss tensor
    """
    # Extract rotation matrices and translations from frames
    pred_R, pred_t = pred_frames
    target_R, target_t = target_frames
    
    # Use translations as positions if not provided
    if pred_positions is None:
        pred_positions = pred_t
    if target_positions is None:
        target_positions = target_t
    if positions_mask is None:
        positions_mask = frames_mask
    
    # Invert target rotation matrices for local frame transformation
    target_R_inv = target_R.transpose(-1, -2)
    
    # Transform predicted positions to local frame of target
    # [*, N_frames, N_pts, 3] = [*, N_frames, 3, 3] @ [*, N_pts, 3, 1]
    # First expand dimensions for broadcasting
    pred_pos_expanded = pred_positions[..., None, :, :]  # [*, 1, N_pts, 3]
    target_R_inv_expanded = target_R_inv[..., None, :, :]  # [*, N_frames, 1, 3, 3]
    target_t_expanded = target_t[..., None, :]  # [*, N_frames, 1, 3]
    
    # Compute local positions: R^-1 (p_pred - p_target)
    local_pred_pos = torch.matmul(
        target_R_inv_expanded, 
        (pred_pos_expanded - target_t_expanded)[..., None]
    ).squeeze(-1)  # [*, N_frames, N_pts, 3]
    
    # Compute target local positions (should be zero in perfect case)
    local_target_pos = torch.matmul(
        target_R_inv_expanded, 
        (target_positions[..., None, :, :] - target_t_expanded)[..., None]
    ).squeeze(-1)  # [*, N_frames, N_pts, 3]
    
    # Compute distance error
    error_dist = torch.sqrt(
        torch.sum((local_pred_pos - local_target_pos) ** 2, dim=-1) + eps
    )
    
    if l1_clamp_distance is not None:
        error_dist = torch.clamp(error_dist, min=0, max=l1_clamp_distance)
    
    normed_error = error_dist / length_scale
    normed_error = normed_error * frames_mask[..., None]
    normed_error = normed_error * positions_mask[..., None, :]
    
    if pair_mask is not None:
        normed_error = normed_error * pair_mask
        normed_error = torch.sum(normed_error, dim=(-1, -2))
        
        mask = frames_mask[..., None] * positions_mask[..., None, :] * pair_mask
        norm_factor = torch.sum(mask, dim=(-2, -1))
        
        normed_error = normed_error / (eps + norm_factor.float())
    else:
        # FP16-friendly averaging with float32 denominators to prevent overflow
        normed_error = torch.sum(normed_error, dim=-1)
        normed_error = (
            normed_error / (eps + torch.sum(frames_mask, dim=-1).float())[..., None]
        )
        normed_error = torch.sum(normed_error, dim=-1)
        normed_error = normed_error / (eps + torch.sum(positions_mask, dim=-1).float())
    
    return normed_error


def compute_hybrid_fape(
    pred_frames: Tuple[torch.Tensor, torch.Tensor],
    target_frames: Tuple[torch.Tensor, torch.Tensor],
    frames_mask: torch.Tensor,
    pred_positions: Optional[torch.Tensor] = None,
    target_positions: Optional[torch.Tensor] = None,
    mask_hcdr3: Optional[torch.Tensor] = None,
    length_scale: float = 10.0,
    l1_clamp_distance: Optional[float] = None,
    eps: float = 1e-8,
) -> torch.Tensor:
    """
    Computes FAPE loss for hybrid regions:
    - HCDR3: uses complete backbone atoms (N, L, 4, 3)
    - Other regions: uses CA atoms (N, L, 3)
    
    Args:
        pred_frames: Tuple of (R, t) where:
            R: [*, N_frames, 3, 3] predicted rotation matrices
            t: [*, N_frames, 3] predicted translation vectors
        target_frames: Tuple of (R, t) where:
            R: [*, N_frames, 3, 3] ground truth rotation matrices
            t: [*, N_frames, 3] ground truth translation vectors
        frames_mask: [*, N_frames] binary mask for the frames
        pred_positions: [*, N_frames, 4, 3] predicted backbone atoms for HCDR3
        target_positions: [*, N_frames, 4, 3] ground truth backbone atoms for HCDR3
        mask_hcdr3: [*, N_frames] binary mask for HCDR3 regions
        length_scale: Length scale by which the loss is divided
        l1_clamp_distance: Cutoff above which distance errors are disregarded
        eps: Small value used to regularize denominators
    
    Returns:
        [*] loss tensor
    """
    pred_R, pred_t = pred_frames
    target_R, target_t = target_frames
    N, L = pred_t.shape[:2]
    
    # Default: use CA atoms for all regions
    loss_fape_ca = compute_fape(
        pred_frames=pred_frames,
        target_frames=target_frames,
        frames_mask=frames_mask,
        length_scale=length_scale,
        l1_clamp_distance=l1_clamp_distance,
        eps=eps
    )
    
    # If no HCDR3 mask, return CA-only loss
    if mask_hcdr3 is None:
        return loss_fape_ca
    
    # Compute backbone FAPE for HCDR3 regions
    # 1. Prepare backbone positions for HCDR3
    if pred_positions is None or target_positions is None:
        return loss_fape_ca
    
    # 2. Flatten backbone atoms for HCDR3 regions
    # Shape: (N, L*4, 3)
    pred_bb_flat = pred_positions.reshape(N, L*4, 3)
    target_bb_flat = target_positions.reshape(N, L*4, 3)
    
    # 3. Create backbone mask
    # Shape: (N, L*4)
    bb_mask = mask_hcdr3.unsqueeze(-1).repeat(1, 1, 4).reshape(N, L*4)
    
    # 4. Create pair mask to connect each residue to its 4 backbone atoms
    # Shape: (N, L, L*4)
    pair_mask = torch.zeros(N, L, L*4, device=mask_hcdr3.device)
    for i in range(N):
        for j in range(L):
            if mask_hcdr3[i, j]:
                pair_mask[i, j, j*4:(j+1)*4] = 1
    
    # 5. Compute FAPE for backbone atoms
    loss_fape_bb = compute_fape(
        pred_frames=pred_frames,
        target_frames=target_frames,
        frames_mask=frames_mask,
        pred_positions=pred_bb_flat,
        target_positions=target_bb_flat,
        positions_mask=bb_mask,
        pair_mask=pair_mask,
        length_scale=length_scale,
        l1_clamp_distance=l1_clamp_distance,
        eps=eps
    )
    
    # 6. Weighted average of CA loss and backbone loss
    # Use to number of residues in each region as weights
    num_res_ca = (frames_mask & ~mask_hcdr3).sum(dim=-1) + eps
    num_res_bb = (frames_mask & mask_hcdr3).sum(dim=-1) + eps
    total_res = num_res_ca + num_res_bb
    
    # 7. Return weighted average with HCDR3 boost factor
    # HCDR3区域虽然残基少，但对抗体功能至关重要，需要增加权重
    weight_hcdr3 = 5.0
    weighted_sum = loss_fape_ca * num_res_ca + loss_fape_bb * num_res_bb * weight_hcdr3
    total_weight = num_res_ca + num_res_bb * weight_hcdr3
    loss_fape = weighted_sum / total_weight.float()
    
    return loss_fape


def torsion_angle_loss(
    a,  # [*, N, 7, 2]
    a_gt,  # [*, N, 7, 2]
    a_alt_gt,  # [*, N, 7, 2]
):
    """
    Computes torsion angle loss between predicted and ground truth torsion angles.
    
    Args:
        a: Predicted torsion angles in sin-cos representation [*, N, 7, 2]
        a_gt: Ground truth torsion angles in sin-cos representation [*, N, 7, 2]
        a_alt_gt: Alternate ground truth torsion angles (for handling periodicity) [*, N, 7, 2]
    
    Returns:
        [*] loss tensor
    """
    # Normalize predicted angles to unit vectors
    norm = torch.norm(a, dim=-1)
    a_normalized = a / norm.unsqueeze(-1)
    
    # Compute squared L2 distances to both ground truth options
    diff_norm_gt = torch.norm(a_normalized - a_gt, dim=-1)
    diff_norm_alt_gt = torch.norm(a_normalized - a_alt_gt, dim=-1)
    min_diff = torch.minimum(diff_norm_gt ** 2, diff_norm_alt_gt ** 2)
    
    # Compute torsion angle loss and angle normalization loss
    l_torsion = torch.mean(min_diff, dim=(-1, -2))
    l_angle_norm = torch.mean(torch.abs(norm - 1), dim=(-1, -2))
    
    # Combine losses with weight for normalization loss
    an_weight = 0.02
    return l_torsion + an_weight * l_angle_norm


def between_residue_bond_loss(
    pred_atom_positions: torch.Tensor,  # (*, N, 14, 3)
    pred_atom_mask: torch.Tensor,  # (*, N, 14)
    residx: torch.Tensor,  # (*, N)
    seq: torch.Tensor,  # (*, N)
    tolerance_factor_soft=12.0,
    tolerance_factor_hard=12.0,
    eps=1e-6,
) -> dict:
    """
    Flat-bottom loss to penalize structural violations between residues.
    
    Args:
        pred_atom_positions: Atom positions in atom14 representation
        pred_atom_mask: Atom mask in atom14 representation
        residx: Residue index for given amino acid (monotonically increasing)
        seq: Amino acid type of given residue
        tolerance_factor_soft: Soft tolerance factor in standard deviations
        tolerance_factor_hard: Hard tolerance factor in standard deviations
    
    Returns:
        Dict containing:
            * 'c_n_loss_mean': Loss for peptide bond length violations
            * 'ca_c_n_loss_mean': Loss for bond angle violations around C (CA-C-N)
    """
    # Initialize loss dictionary
    loss_dict = {
        'c_n_loss_mean': torch.tensor(0.0, device=pred_atom_positions.device),
        'ca_c_n_loss_mean': torch.tensor(0.0, device=pred_atom_positions.device),
    }
    
    # Get batch dimensions and sequence length
    batch_dims = pred_atom_positions.shape[:-3]
    N = pred_atom_positions.shape[-3]
    
    if N < 2:
        return loss_dict
    
    # Get positions of relevant atoms (C, N, CA)
    # Atom14 indices: N=0, CA=1, C=2, O=3
    c_pos = pred_atom_positions[..., :-1, 2, :]  # C from residue i
    n_pos = pred_atom_positions[..., 1:, 0, :]   # N from residue i+1
    ca_pos = pred_atom_positions[..., :-1, 1, :] # CA from residue i
    
    # Create mask for consecutive residues
    consecutive_mask = (residx[..., 1:] == residx[..., :-1] + 1).unsqueeze(-1)
    
    # Calculate peptide bond length (C-N)
    c_n_distance = torch.norm(c_pos - n_pos, dim=-1)
    c_n_mean = 1.335  # Average C-N bond length
    c_n_std = 0.02    # Standard deviation
    
    # Calculate bond angle (CA-C-N)
    v1 = c_pos - ca_pos
    v2 = n_pos - c_pos
    ca_c_n_angle = torch.acos(
        torch.clamp(torch.sum(v1 * v2, dim=-1) / (torch.norm(v1, dim=-1) * torch.norm(v2, dim=-1) + eps), -1.0 + 1e-6, 1.0 - 1e-6)
    )
    ca_c_n_mean = 2.073  # Average CA-C-N bond angle in radians (118.8 degrees)
    ca_c_n_std = 0.05    # Standard deviation
    
    # Apply flat-bottom loss for C-N bond length
    c_n_diff = torch.abs(c_n_distance - c_n_mean)
    c_n_soft = tolerance_factor_soft * c_n_std
    c_n_hard = tolerance_factor_hard * c_n_std
    
    c_n_loss = torch.zeros_like(c_n_distance)
    mask_c_n = c_n_diff > c_n_soft
    c_n_loss[mask_c_n] = (
        (c_n_diff[mask_c_n] - c_n_soft) / (c_n_hard - c_n_soft)
    )
    c_n_loss = torch.clamp(c_n_loss, 0.0, 1.0)
    
    # Apply flat-bottom loss for CA-C-N bond angle
    ca_c_n_diff = torch.abs(ca_c_n_angle - ca_c_n_mean)
    ca_c_n_soft = tolerance_factor_soft * ca_c_n_std
    ca_c_n_hard = tolerance_factor_hard * ca_c_n_std
    
    ca_c_n_loss = torch.zeros_like(ca_c_n_angle)
    mask_ca_c_n = ca_c_n_diff > ca_c_n_soft
    ca_c_n_loss[mask_ca_c_n] = (
        (ca_c_n_diff[mask_ca_c_n] - ca_c_n_soft) / (ca_c_n_hard - ca_c_n_soft)
    )
    ca_c_n_loss = torch.clamp(ca_c_n_loss, 0.0, 1.0)
    
    # Apply consecutive mask
    c_n_loss = c_n_loss * consecutive_mask.squeeze(-1)
    ca_c_n_loss = ca_c_n_loss * consecutive_mask.squeeze(-1)
    
    # Calculate mean losses
    valid_c_n = torch.sum(consecutive_mask) + eps
    valid_ca_c_n = torch.sum(consecutive_mask) + eps
    
    loss_dict['c_n_loss_mean'] = torch.sum(c_n_loss) / valid_c_n
    loss_dict['ca_c_n_loss_mean'] = torch.sum(ca_c_n_loss) / valid_ca_c_n
    
    return loss_dict


def between_residue_clash_loss(
    final_atom14_positions: torch.Tensor,
    atom14_atom_exists: torch.Tensor,
    atom14_atom_radius: torch.Tensor,
    residx: torch.Tensor,
    asym_id: Optional[torch.Tensor] = None,
    overlap_tolerance_soft=1.5,
    overlap_tolerance_hard=1.5,
    eps=1e-10,
) -> dict:
    """
    Loss to penalize steric clashes between residues.
    
    Args:
        final_atom14_positions: Predicted atom positions in atom14 representation
        atom14_atom_exists: Mask denoting whether atom exists for given amino acid
        atom14_atom_radius: Van der Waals radius for each atom
        residx: Residue index for given amino acid
        asym_id: Asymmetric unit ID for each residue (optional)
        overlap_tolerance_soft: Soft tolerance factor
        overlap_tolerance_hard: Hard tolerance factor
    
    Returns:
        Dict containing:
            * 'mean_loss': Average clash loss
            * 'per_atom_loss_sum': Sum of all clash losses per atom
    """
    # Initialize loss dictionary
    loss_dict = {
        'mean_loss': torch.tensor(0.0, device=final_atom14_positions.device),
        'per_atom_loss_sum': torch.zeros_like(atom14_atom_exists[..., 0]),
    }
    
    # Get batch dimensions and sequence length
    batch_dims = final_atom14_positions.shape[:-3]
    N = final_atom14_positions.shape[-3]
    
    if N < 2:
        return loss_dict
    
    # Create mask for non-consecutive residues
    # Only check clashes between residues that are not adjacent
    idx_grid = torch.arange(N, device=final_atom14_positions.device)
    idx_i, idx_j = torch.meshgrid(idx_grid, idx_grid, indexing='ij')
    
    # Mask for same residue or adjacent residues
    same_or_adjacent = torch.abs(idx_i - idx_j) <= 1
    
    # Add residue index check
    residx_i, residx_j = torch.meshgrid(residx[0], residx[0], indexing='ij')
    same_or_adjacent = same_or_adjacent | (torch.abs(residx_i - residx_j) <= 1)
    
    # If asym_id is provided, only check clashes within same chain
    if asym_id is not None:
        asym_i, asym_j = torch.meshgrid(asym_id[0], asym_id[0], indexing='ij')
        same_or_adjacent = same_or_adjacent | (asym_i != asym_j)
    
    # Reshape masks for broadcasting
    same_or_adjacent = same_or_adjacent.unsqueeze(0).repeat(*batch_dims, 1, 1)
    
    # Calculate pairwise distances between all atoms
    # Shape: [*, N, 14, 3] -> [*, N, 14, 1, 3]
    pos_i = final_atom14_positions.unsqueeze(-2)
    # Shape: [*, N, 1, 14, 3]
    pos_j = final_atom14_positions.unsqueeze(-3)
    
    # Calculate distances: [*, N, 14, N, 14]
    distances = torch.norm(pos_i - pos_j, dim=-1)
    
    # Get atom radii: [*, N, 14]
    radii_i = atom14_atom_radius.unsqueeze(-1).unsqueeze(-1)
    radii_j = atom14_atom_radius.unsqueeze(-2).unsqueeze(-2)
    
    # Calculate expected minimum distance: [*, N, 14, N, 14]
    min_distance = radii_i + radii_j
    
    # Calculate overlap: [*, N, 14, N, 14]
    overlap = min_distance - distances
    
    # Apply mask for same/adjacent residues
    overlap = overlap * (~same_or_adjacent).unsqueeze(-1).unsqueeze(-1)
    
    # Apply atom existence mask
    exists_i = atom14_atom_exists.unsqueeze(-1).unsqueeze(-1)
    exists_j = atom14_atom_exists.unsqueeze(-2).unsqueeze(-2)
    overlap = overlap * exists_i * exists_j
    
    # Calculate flat-bottom loss
    soft_tolerance = overlap_tolerance_soft
    hard_tolerance = overlap_tolerance_hard
    
    clash_loss = torch.zeros_like(overlap)
    mask = overlap > soft_tolerance
    clash_loss[mask] = (
        (overlap[mask] - soft_tolerance) / (hard_tolerance - soft_tolerance)
    )
    clash_loss = torch.clamp(clash_loss, 0.0, 1.0)
    
    # Sum over all atom pairs
    per_atom_loss_sum = torch.sum(clash_loss, dim=(-1, -2))
    mean_loss = torch.mean(per_atom_loss_sum)
    
    loss_dict['mean_loss'] = mean_loss
    loss_dict['per_atom_loss_sum'] = per_atom_loss_sum
    
    return loss_dict


def flow_consistency_loss(flow_t1, flow_t2, composed_flow, mask):
    """
    Computes flow consistency loss to enforce smoothness and consistency of flow paths.
    
    Args:
        flow_t1: Flow from time t1 to end point [*, N, D]
        flow_t2: Flow from time t2 to end point [*, N, D]
        composed_flow: Composed flow from t1 to 0 then to t2 [*, N, D]
        mask: Valid sequence position mask [*, N]
    
    Returns:
        [*] loss tensor
    """
    import torch.nn.functional as F
    
    # Compute MSE loss between flow_t1 and composed_flow
    mse_loss = F.mse_loss(flow_t1, composed_flow, reduction='none')
    
    # Apply mask and normalize by number of valid positions and dimensions
    loss = (mse_loss * mask.unsqueeze(-1)).sum() / (mask.sum() * mse_loss.shape[-1] + 1e-8)
    
    return loss
